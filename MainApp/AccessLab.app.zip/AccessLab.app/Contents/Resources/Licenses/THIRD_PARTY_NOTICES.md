# Third-party components

AccessLab uses the C++17 standard library, libsodium, and Qt 6 Core/Gui/Widgets. Qt Test is used only by the automated GUI tests.

## Qt

The supplied macOS desktop bundle dynamically links unmodified Qt 6.10.0 Core, Gui, and Widgets libraries and deployment plugins from the official Qt distribution. Qt is copyright The Qt Company and its contributors. The open-source license applicable to these modules includes LGPL version 3. See the included `licenses/LGPL-3.0-only.txt` and referenced `licenses/GPL-3.0-only.txt`.

Qt source for this exact version is available from:

- https://download.qt.io/archive/qt/6.10/6.10.0/submodules/qtbase-everywhere-src-6.10.0.tar.xz
- https://code.qt.io/cgit/qt/qtbase.git/tree/?h=v6.10.0

The application uses shared libraries rather than static Qt linkage. The macOS bundle's Qt libraries live in `Contents/Frameworks` and its plugins in `Contents/PlugIns`. The project source and build instructions are supplied, so it can be rebuilt against a compatible modified Qt installation. Local modifications to a macOS bundle may require a fresh local code signature.

Qt also includes third-party components. The packaged Qt module SPDX software bills of materials are included with the macOS bundle's license notices for attribution and component details. Their license identifiers refer to the corresponding component sources in the Qt source distribution.

## libsodium

The verified build uses libsodium 1.0.22, copyright Frank Denis and contributors, under the ISC license. Its full notice is included in `licenses/libsodium-LICENSE.txt`.

- https://github.com/jedisct1/libsodium/tree/1.0.22-RELEASE
- https://download.libsodium.org/libsodium/releases/

No Qt SDK or libsodium source is embedded in this source project. Install development packages as described in README. The separate macOS bundle includes the required dynamic runtime libraries.
